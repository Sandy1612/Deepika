package com.capgemini.doctors.dao;

import static org.junit.Assert.*;

import org.junit.Test;

public class DoctorAppointmentDaoTest {

	
	
	@Test
	public void testAddDoctorAppointmentDetails() {
		
	}

	@Test
	public void testGetAppointmentDetails() {
		fail("Not yet implemented");
	}

}
