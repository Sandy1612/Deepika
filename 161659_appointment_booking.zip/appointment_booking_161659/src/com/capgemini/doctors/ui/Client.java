package com.capgemini.doctors.ui;

import java.time.LocalDate;
import java.util.Scanner;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.service.DoctorAppointmentService;


public class Client {
	@SuppressWarnings({ "resource", "unused" })
	
	
	
	
	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		DoctorAppointmentService service = new DoctorAppointmentService();
		DoctorAppointment doctorAppointment1 = new DoctorAppointment();

		int appointmentId;
		String patientName;
		String phoneNumber;
		String email;
		String gender;
		LocalDate appointmentDate;
		int age;
		String problemName;
		String doctorName;
		String appointmentStatus;
		int choice;

		System.out.println("Welcome\n");
		
		try{
			do{
		System.out.println("Menu\n\n");
        System.out.println("1) Book Doctor Appointment\n2) View Doctor Appointment\n3) Exit");
        System.out.println("enter choice");
		choice = scan.nextInt();


		switch (choice) {
		case 1:
			DoctorAppointment doctorAppointment = new DoctorAppointment();

			do{
				System.out.println("Enter Name of the patient   :"); 
			patientName = scan.next();
			if(service.validate_patientName(patientName)==false)
				System.out.println("Please enter a valid name");
				}while(service.validate_patientName(patientName)==false);
			
			
			
			do{
				System.out.println("Enter Phone Number          :"); phoneNumber = scan.next();
			if(service.validate_phoneNumber(phoneNumber)==false)
				System.out.println("Please enter a valid name");
				}while(service.validate_phoneNumber(phoneNumber)==false);
			
			
			do{
				System.out.println("Enter Email                 :"); email = scan.next();
			if(service.validate_email(email)==false)
				System.out.println("Please enter a valid name");
				}while(service.validate_email(email)==false);
			
			
			do{
				System.out.println("Enter Age                   :"); age = scan.nextInt();
			if(service.validate_age(age)==false)
				System.out.println("Please enter a valid name");
				}while(service.validate_age(age)==false);
			do{
				System.out.println("Enter Gender                :"); gender = scan.next();
			if(service.validate_gender(gender)==false)
				System.out.println("Please enter a valid name");
				}while(service.validate_gender(gender)==false);
			do{
				System.out.println("Enter Problem Name          :"); problemName = scan.next();
			if(service.validate_problemName(problemName)==false)
				System.out.println("Please enter a valid name");
				}while(service.validate_problemName(problemName)==false);
			

			doctorAppointment.setPatientName(patientName);
			doctorAppointment.setEmail(email);
			doctorAppointment.setGender(gender);
			doctorAppointment.setAge(age);
			doctorAppointment.setProblemName(problemName);
			doctorAppointment.setAppointmentStatus("DISAPPROVED");
			service.setApproval(problemName,doctorAppointment);
			
			if(service.addDoctorAppointmentDetails(doctorAppointment)==0){
				System.out.println("Your Doctor Appointment has been successfully registered");
				System.out.println("your appointment ID is : " +doctorAppointment.getAppointmentId());
			}
			System.out.println("enter 1 to return menu");
			choice= scan.nextInt();
			break;

		case 2:
			System.out.println("Enter the appointment Id :");
			appointmentId = scan.nextInt();
			doctorAppointment1=service.getDoctorAppointmentDetails(appointmentId);
			System.out.println("Patient Name         : "+doctorAppointment1.getPatientName());
			System.out.println("Appointment Status   : "+doctorAppointment1.getAppointmentStatus());
			System.out.println("Doctor Name          : "+doctorAppointment1.getDoctorName());

			System.out.println("enter 1 to return menu");
			choice= scan.nextInt();
			break;
		case 3:
			
			System.exit(0);
		
		default:
			break;
		} 
			}while((choice==1));
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
        
	}

}
