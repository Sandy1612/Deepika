package com.cg.sel;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ByClassName;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.touch.TouchActions;

import com.gargoylesoftware.htmlunit.javascript.host.event.KeyboardEvent;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws InterruptedException
    {
    	WebElement  el=null;
        //System.out.println( "Hello World!" );
    	System.setProperty("webdriver.chrome.driver", "D:\\drivers\\sel\\chromedriver.exe");
    	WebDriver wb = new ChromeDriver();
    	wb.get("https://www.google.com");
    	System.out.println(wb.getCurrentUrl());
    	//System.out.println(wb.getWindowHandle());
    	//System.out.println(wb.getPageSource());
    	System.out.println(wb.getTitle());
    	//el.sendKeys("0x85");
    	wb.navigate().refresh();
    	//TouchActions action = new TouchActions(wb);
    	
    	el = wb.findElement(By.name("q"));
    	String s="javatp";
    	el.sendKeys(s);
    	wb.manage().timeouts().implicitlyWait(105, TimeUnit.SECONDS);
    	el = wb.findElement(By.xpath("//*[@id=\"tsf\"]/div[2]/div/div[2]/div[2]/ul/li[1]/div[1]"));
    	el.click();
    	wb.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
    	el = wb.findElement(By.xpath("//*[@id=\"rso\"]/div[1]/div/div/div/div/div[1]/a/h3"));
    	el.click();
    	wb.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
    	el = wb.findElement(By.xpath("//*[@id=\"link\"]/div/ul/li[4]/a"));
    	el.click();
    	wb.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
    	el = wb.findElement(By.xpath("//*[@id=\"city\"]/table/tbody/tr/td/div[2]/div[2]/ul/li[12]/ul/li[8]/a"));
    	el.click();
    	//wb.manage().timeouts().implicitlyWait(5000, TimeUnit.SECONDS);//*[@id="city"]/table/tbody/tr/td/div[2]/div[2]/ul/li[12]/ul/li[8]/a
    	/*try {
			wb.wait(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
    	wb.manage().timeouts().implicitlyWait(15000, TimeUnit.SECONDS);

    	wb.close();
    	
    }
}
