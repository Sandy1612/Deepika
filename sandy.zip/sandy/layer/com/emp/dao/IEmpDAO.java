package com.emp.dao;

import com.emp.bean.Employee;


public interface IEmpDAO {
	
	public boolean createAccount(Employee e);
	public double showBalance(String acunt_num);
	public boolean deposite(double temp, String acunt_num);
	public boolean withdraw(double temp, String acunt_num);
	public String printTransaction(String acunt_num);
	//public void fundTransfer();
	

}
