package com.collection;

import com.collection.Samp;

public class Gen {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Samp myEmail = new Samp();
		myEmail.setFrom("test@igate.com");
		
		System.out.println(myEmail);
		
		
		
	}

}
