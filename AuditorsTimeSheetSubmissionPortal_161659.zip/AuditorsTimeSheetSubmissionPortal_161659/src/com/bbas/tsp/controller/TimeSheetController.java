package com.bbas.tsp.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.bbas.tsp.entity.TimeSheetEntity;
import com.bbas.tsp.exception.TimeSheetException;
import com.bbas.tsp.service.ITimeSheetService;



@Controller
public class TimeSheetController {
	
	
	
    
	@Autowired
	ITimeSheetService timeSheetService;
	
	@RequestMapping(value="home")
	public String returnHome(){
		return "Home";
	}
	
	@RequestMapping(value="entertimesheet")
	public ModelAndView enterTimeSheet(@ModelAttribute("details") TimeSheetEntity timeSheet, Map<String,Object> activityMap) throws TimeSheetException{
		
		SimpleDateFormat dateFormatter = new SimpleDateFormat("dd/MM/yyyy");  
	    String currentDate= dateFormatter.format(new Date());
		activityMap.put("activity", timeSheetService.getActivityList());
		return new ModelAndView("TimeSheetEntry", "date", currentDate);
	}
	
	
	
	@RequestMapping(value="success")
	public ModelAndView timeSheet(@Valid @ModelAttribute("details") TimeSheetEntity timeSheet, BindingResult result) throws TimeSheetException{ 
		try {
			if(result.hasErrors()) {
				List<ObjectError> errorList=result.getAllErrors();
				System.out.println(errorList);
				return new ModelAndView("Success", "timesheet_id", "Error in processing");      // Shows error if does not satisfy validation

			}else {
		timeSheet.setTimesheet_date();                                                          //setting date in object
		timeSheet.setTimesheet_id(null);		                                                //Assigning to null as to auto generate  
		return new ModelAndView("Success", "timesheet_id", timeSheetService.SaveTimeSheet(timeSheet));
			}
		} catch (Exception e) {			
			return new ModelAndView("Success", "timesheet_id", "Error in processing"); 
		}	
	}
	
	
	
	

}
