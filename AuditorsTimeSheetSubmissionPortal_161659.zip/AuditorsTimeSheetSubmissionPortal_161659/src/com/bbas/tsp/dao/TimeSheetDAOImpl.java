package com.bbas.tsp.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.bbas.tsp.entity.TimeSheetEntity;
import com.bbas.tsp.exception.TimeSheetException;

@Repository
@Transactional
public class TimeSheetDAOImpl implements ITimeSheetDAO{

	@PersistenceContext
	EntityManager entityManager;
	
	
	@Override
	public Integer SaveTimeSheet(TimeSheetEntity timeSheet)
			throws TimeSheetException {
		
		try{
		
		entityManager.persist(timeSheet);                 //  saving it in database
		return timeSheet.getTimesheet_id();              //   returning id to display in success page
	}catch(Exception e) {
		e.printStackTrace();
		throw new TimeSheetException(e.getMessage());
	}
	
	
	}

}
