package com.bbas.tsp.dao;

import com.bbas.tsp.entity.TimeSheetEntity;
import com.bbas.tsp.exception.TimeSheetException;

public interface ITimeSheetDAO {
	public Integer SaveTimeSheet(TimeSheetEntity timeSheet) throws TimeSheetException;

	
}
