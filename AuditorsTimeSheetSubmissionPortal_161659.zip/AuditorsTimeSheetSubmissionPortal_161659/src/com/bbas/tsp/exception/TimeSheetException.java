package com.bbas.tsp.exception;

public class TimeSheetException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7539982195722255928L;

	public TimeSheetException(String message) {

		super(message);
	}

}
