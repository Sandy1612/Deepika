package com.bbas.tsp.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bbas.tsp.dao.ITimeSheetDAO;
import com.bbas.tsp.entity.TimeSheetEntity;
import com.bbas.tsp.exception.TimeSheetException;


@Service
@Transactional
public class TimeSheetServiceImpl implements ITimeSheetService{

	@Autowired
	ITimeSheetDAO timeSheetDao;
	
	
	@Override
	public Integer SaveTimeSheet(TimeSheetEntity timeSheet)
			throws TimeSheetException {
		try{
		return timeSheetDao.SaveTimeSheet(timeSheet);
		}catch(Exception e) {
			e.printStackTrace();
			throw new TimeSheetException(e.getMessage());
		}
	}


	@Override
	public List<String> getActivityList() throws TimeSheetException {                  // Method to show the Activity drop down in the web page
		List<String> activityList=new ArrayList<>();
		activityList.add("--SELECT--");
		activityList.add("DATA_ENTRY");
		activityList.add("ACCOUNTS_TALLY");
		activityList.add("LEDGER_POSTINGS");
		activityList.add("BALANCE_SHEET");
		activityList.add("RETURNS_FILING");
		return activityList;
	}

}
