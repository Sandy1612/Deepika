package com.bbas.tsp.service;

import java.util.List;

import com.bbas.tsp.entity.TimeSheetEntity;
import com.bbas.tsp.exception.TimeSheetException;


public interface ITimeSheetService {

	
	public Integer SaveTimeSheet(TimeSheetEntity timeSheet) throws TimeSheetException;
	public List<String> getActivityList() throws TimeSheetException;
	
}
