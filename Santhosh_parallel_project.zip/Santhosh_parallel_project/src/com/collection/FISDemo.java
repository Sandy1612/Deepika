package com.collection;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FISDemo {

	public static void main(String[] args) {

		FileReader input = null;
		FileWriter output = null;
		try{
			
		input = new FileReader("input.txt");
		
		output = new FileWriter("output.txt");
		
		
		int n;
				
		while((n=input.read()) != -1 ){
			
			System.out.print((char)n);
			
			output.flush();
			output.write(n);
			
			
		}
		
		}
		catch (FileNotFoundException e){
			e.printStackTrace();
		}catch (IOException e){
			e.printStackTrace();
		}
		finally {
			
			try {
				input.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		}
	}

}
