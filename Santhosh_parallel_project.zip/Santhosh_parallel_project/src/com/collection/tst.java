package bankdetails;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class bankTest {

	
	bank b = new bank();
	
	
	
	
	
	
	
	@BeforeClass
	public void testCreateAccount() {
		//fail("Not yet implemented");
		
		assertNotNull(b.PAN);
		assertNotNull(b.aadhar);
			
	}

	@Test
	public void testShowBalance() {
		//fail("Not yet implemented");
		assertNotNull(b.bal);
	}

	@Test
	public void testDeposit() {
		//fail("Not yet implemented");
		
	}

	@Test
	public void testWithDraw() {
		//fail("Not yet implemented");
	}

	@Test
	public void testFundTransfer() {
		//fail("Not yet implemented");
	}

	@Test
	public void testPrintTransfer() {
		//fail("Not yet implemented");
	}

	@Before
	public void testCheck() {
		//fail("Not yet implemented");
		assertNotNull(b.acnt_no);
		assertSame(5678, );
	}

}
