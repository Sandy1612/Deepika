package com.collection;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class MapDemo {
	
	public static void main(String[] args){
	
		Map<Integer,String> m = new HashMap<Integer,String>();
		
		m.put(101, "raju");
		m.put(102, "scott");
		m.put(103, "king");
		m.put(104, "ravi");
		
		Set s = m.keySet();
		
		Iterator<Integer> it = s.iterator();
		
		while (it.hasNext()) {
			Integer key = it.next();
			
			System.out.println(key+" "+m.get(key));
		}
		
		
		
		
	}

}
