package com.collection;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class FWDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
	 String s;
		
		int n;
		
		try {
			System.out.println("enter the data");
			while( !(s=br.readLine()).equals("#"))
			{
				System.out.println(s);
			}
			
			n = br.read();
			System.out.println((char)n);
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
	}

}
