package com.collection;
import java.math.*;
public class Person {

	public enum Gender{M,F;}
   
    public Person()
    {
        
    }
    
    public String Person(String string, String string2, Gender m, BigInteger i) {
		// TODO Auto-generated constructor stub
    	 return "FirstName: "+string+"\n"+"LastName: "+string2+"\n"+"Gender: "+m+"\n"+"Number: "+i;
    }
	


   
  /* public void getDetails()
   {
       Gender g1 = Gender.M;
       Gender g2 = Gender.F;
       BigInteger n = BigInteger.valueOf(999999999);
       
   // Person.displayDetails(p);
   }*/
	    
	    
	
	public static void main(String[] args) {
		//Object n;
		//Object g1;
		// TODO Auto-generated method stub
		 Person p = new Person("ABC","DEF",Gender.M,999999999);
	
	

		  
		   
		    
		    
		    
	}
}
		

