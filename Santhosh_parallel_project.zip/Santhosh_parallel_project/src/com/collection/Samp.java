package com.collection;

public class Samp {
	private String from;

	public String getFrom() {
		return from;
	}
	public void setFrom(String from) {
		this.from = from;
	}
	
	@override		
	public String toString() {
			return "Email [from=" + from + "]";
	}
}
