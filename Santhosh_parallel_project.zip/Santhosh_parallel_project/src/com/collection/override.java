package com.collection;

public @interface override {

}
