package com.collection;




class Account {
	  double balance;
	  boolean withdraw(double bal){
	    this.balance = this.balance - bal;
	    return true;
	  }
	}

	public class SavingsAccount()
	{
	    final minbalance=500;
	    
	    
	}
public class client {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		

	}

}
