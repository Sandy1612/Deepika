package com.emp.service;

import com.emp.bean.Employee;

public interface IEmpService {
	
	public boolean createAccount(Employee e);
	public double showBalance(String acunt_num);
	public boolean deposite(double dep,String acunt_num);
	public boolean withdraw(double wit,String acunt_num);
	public String printTransaction(String acunt_num);
	//public void fundTransfer();
	
	
}
