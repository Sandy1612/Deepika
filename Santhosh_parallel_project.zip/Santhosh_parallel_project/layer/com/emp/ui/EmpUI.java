package com.emp.ui;

import java.util.Scanner;

import com.emp.bean.Employee;
import com.emp.service.EmpService;

public class EmpUI {
	
	private static Scanner sc;

	public static void main(String[] args){
		
		EmpService sr = new EmpService();
		Employee e = new Employee();
				
		
		String ename;
		String pan;
		String ph_num;
		String aadhar;
		String pin;
		String acunt_num;
		String transfer_acunt_num;
		int choice;
		sc = new Scanner(System.in);
		
		System.out.println("Welcome");
		
		do{
		System.out.println("Menu\n");
        System.out.println("1.Create Account\n2.Check Balance\n3.Deposit\n4.Withdraw\n5.Fund Transer\n6.Print transaction");
        System.out.println("enter choice");
		
		
		
		choice = sc.nextInt();
		
		
		
		switch (choice) {
		case 1:
			Employee e1=new Employee();
			
			do{
			System.out.println("Enter your name");
			ename = sc.next();
			if(sr.valename(ename)==false)
				System.out.println("Please enter a valid name");
				}while(sr.valename(ename)==false);
			
			do{
			System.out.println("Enter your mobile number");
			ph_num = sc.next();
			if(sr.valph_num(ph_num)==false)
				System.out.println("Please enter a valid mobile number");
				}while(sr.valph_num(ph_num)==false);
			
			do{
			System.out.println("enter your AADHAR");
			aadhar = sc.next();
			if(sr.valaadhar(aadhar)==false)
				System.out.println("your ID is worng");
				}while(sr.valaadhar(aadhar)==false);
			do{
				System.out.println("Enter your pan ID in capital letters");
				pan = sc.next();
				if(sr.valpan(pan)==false)
				System.out.println("your ID is worng");
				}while(sr.valpan(pan)==false);
				
			do{
				System.out.println("enter a 4 digit pin for your account");
				pin = sc.next();
				if(sr.valpin(pin)==false)
					System.out.println("your pin is worng");
					}while(sr.valpin(pin)==false);
			
			acunt_num = ph_num;
			double balance = 0;
		
			
			
			e1.setEname(ename);
			e1.setPh_num(ph_num);
			e1.setpan(pan);
			e1.setaadhar(aadhar);
			e1.setAcunt_num(acunt_num);
			e1.setBalance(balance);
			e1.setPin(pin);
			e1.setHist("Account opened\n");
			
			if(true==sr.createAccount(e1))
			{
				 System.out.println("\nHi "+e1.getEname()+". your account created successfully");
				    System.out.println("your Account number is "+e1.getAcunt_num()+"\n\n");
			}else{
				System.out.println("enter valid details");
			}
			
			System.out.println("Press 8 for menu\nPress 9 to exit");
			choice=sc.nextInt();
			break;
		case 2:
			
			do{
			System.out.println("Enter your account number");
			acunt_num = sc.next();
			if(sr.valph_num(acunt_num)==false)
				System.out.println("your ID is worng");
				}while(sr.valph_num(acunt_num)==false);
			
			
			do{
				System.out.println("Enter your pin");
				pin = sc.next();
				if(sr.valpin(pin)==false)
					System.out.println("Invalid pin");
					}while(sr.valpin(pin)==false);
				
			if(sr.check(acunt_num,pin)==true)
			{
			System.out.println("your account balance is"+sr.showBalance(acunt_num));
			}else
			{
				System.out.println("Account Number or PIN is not valid\n");
			}
			System.out.println("Press 8 for menu\nPress 9 to exit");
			choice=sc.nextInt();
			break;
            
        case 3:
        	
        	do{
    			System.out.println("Enter your account number");
    			acunt_num = sc.next();
    			if(sr.valph_num(acunt_num)==false)
    				System.out.println("your ID is worng");
    				}while(sr.valph_num(acunt_num)==false);
    			
    			
    			do{
    				System.out.println("Enter your pin");
    				pin = sc.next();
    				if(sr.valpin(pin)==false)
    					System.out.println("Invalid pin");
    					}while(sr.valpin(pin)==false);
    			
    			if(sr.check(acunt_num,pin)==true)
    			{
    				System.out.println("enter the amount to be deposited");
    				double d = sc.nextDouble();
    				if(sr.deposite(d,acunt_num))
    					System.out.println("amount is deposited and the balance is "+sr.showBalance(acunt_num));
    				
    			
    			}
    			else
    			{
    				System.out.println("Account Number or PIN is not valid");
    			}
        	
    			System.out.println("Press 8 for menu\nPress 9 to exit");
    			choice=sc.nextInt();
            break;

            
        case 4:
        	 
        	do{
    			System.out.println("Enter your account number");
    			acunt_num = sc.next();
    			if(sr.valph_num(acunt_num)==false)
    				System.out.println("your ID is worng");
    				}while(sr.valph_num(acunt_num)==false);
    			
    			
    			do{
    				System.out.println("Enter your pin");
    				pin = sc.next();
    				if(sr.valpin(pin)==false)
    					System.out.println("Invalid pin");
    					}while(sr.valpin(pin)==false);
    			
    			
    			if(sr.check(acunt_num,pin)==true)
    			{
    				if(sr.showBalance(acunt_num)<500){
    					System.out.println("you have only minimum balance");
    				}else{
    					System.out.println("enter the amount to be withdrawn");
    					double d = sc.nextDouble();
    					if( (sr.showBalance(acunt_num)-d) > 500){
    						if(sr.withdraw(d,acunt_num))
    							System.out.println("amount is withdrawn and the balance is "+sr.showBalance(acunt_num));
    					}else
    					{
    						System.out.println("minimum balance error"+sr.showBalance(acunt_num));
    					}
    					
    				}
    			
    			
    			}
    			else
    			{
    				System.out.println("Account Number or PIN is not valid");
    			}
        	
    			System.out.println("Press 8 for menu\nPress 9 to exit");
    			choice=sc.nextInt();
        	
        	break;
        	
        case 5:
        	
        	do{
    			System.out.println("Enter your account number");
    			acunt_num = sc.next();
    			if(sr.valph_num(acunt_num)==false)
    				System.out.println("your ID is worng");
    				}while(sr.valph_num(acunt_num)==false);
    			
    			
    			do{
    				System.out.println("Enter your pin");
    				pin = sc.next();
    				if(sr.valpin(pin)==false)
    					System.out.println("Invalid pin");
    					}while(sr.valpin(pin)==false);
    			
    			if(sr.check(acunt_num,pin)==true)
    			{
    				do{
    	    			System.out.println("Enter your account number to be transfered");
    	    			transfer_acunt_num = sc.next();
    	    			if(sr.valph_num(transfer_acunt_num)==false)
    	    				System.out.println("your ID is worng");
    	    				}while(sr.valph_num(transfer_acunt_num)==false);
    	    			
    				
    				if(sr.check(transfer_acunt_num)==true)
    				{
    				System.out.println("enter the amount to be transfered");
    				double d = sc.nextDouble();
    				if( (sr.showBalance(acunt_num)-d) > 500)
    				{
						if(sr.withdraw(d,acunt_num))
							System.out.println("amount is Transfered to "+transfer_acunt_num+" and the balance is "+sr.showBalance(acunt_num));
						if(sr.deposite(d,transfer_acunt_num))
	    					System.out.println("amount "+d+" is received by "+acunt_num);
						
					}else
					{
						System.out.println("minimum balance error"+sr.showBalance(acunt_num));
					}
    				
    			
    			}else
    			{
    				System.out.println("account doesn't exist");
    			}
    			
    			}
    			else
    			{
    				System.out.println("Account Number or PIN is not valid");
    			}
    			
    		
    			System.out.println("Press 8 for menu\nPress 9 to exit");
    			choice=sc.nextInt();
        	break;
        	
        case 6:
        	
        	do{
    			System.out.println("Enter your account number");
    			acunt_num = sc.next();
    			if(sr.valph_num(acunt_num)==false)
    				System.out.println("your ID is worng");
    				}while(sr.valph_num(acunt_num)==false);
    			
    			
    			do{
    				System.out.println("Enter your pin");
    				pin = sc.next();
    				if(sr.valpin(pin)==false)
    					System.out.println("Invalid pin");
    					}while(sr.valpin(pin)==false);
    			
    			if(sr.check(acunt_num,pin)==true)
    			{
    				System.out.println(sr.printTransaction(acunt_num));
    				  				
    			
    			}
    			else
    			{
    				System.out.println("Account Number or PIN is not valid");
    			}			
    			
    			
    			
    			System.out.println("Press 8 for menu\nPress 9 to exit");
    			choice=sc.nextInt();
    			
    			
        	break;
        	
        	
		default:
			System.out.println("enter a valid number");
			break;
		}
		
		//34/45
		
		}while(choice!=9);
	}

}// [\/\]|[\.\][\-\]
